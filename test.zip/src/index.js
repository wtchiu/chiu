// let b1 = document.getElementById("box1");
// let b2 = document.getElementById("box2");
// let b3 = document.getElementById("box3");
// let b4 = document.getElementById("box4");
// let b5 = document.getElementById("box5");

let boxes = document.getElementsByClassName("box");
let boxesArray = [...boxes];

for (let i = 0; i < boxesArray.length; i++) {
  let box = boxesArray[i];
  box.onclick = (e) => {
    for (let j = 0; j < boxesArray.length; j++) {
      let _box = boxesArray[j];
      if (_box.classList.contains("active")) {
        _box.classList.remove("active");
      }
    }

    e.target.classList.add("active");
  };
}

// b1.onclick = () => {
//   b1.classList.add("active");
//   b2.classList.remove("active");
//   b3.classList.remove("active");
//   b4.classList.remove("active");
//   b5.classList.remove("active");
// };

// b2.onclick = () => {
//   b2.classList.add("active");
//   b1.classList.remove("active");
//   b3.classList.remove("active");
//   b4.classList.remove("active");
//   b5.classList.remove("active");
// };

// b3.onclick = () => {
//   b3.classList.add("active");
//   b2.classList.remove("active");
//   b1.classList.remove("active");
//   b4.classList.remove("active");
//   b5.classList.remove("active");
// };

// b4.onclick = () => {
//   b4.classList.add("active");
//   b2.classList.remove("active");
//   b3.classList.remove("active");
//   b1.classList.remove("active");
//   b5.classList.remove("active");
// };

// b5.onclick = () => {
//   b5.classList.add("active");
//   b2.classList.remove("active");
//   b3.classList.remove("active");
//   b4.classList.remove("active");
//   b1.classList.remove("active");
// };
